﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace fit5032_week3.HelloWorld
{
    public class Hello
    {
        public String GetHello()
        {
            return "Hello World!";
        }
    }
}