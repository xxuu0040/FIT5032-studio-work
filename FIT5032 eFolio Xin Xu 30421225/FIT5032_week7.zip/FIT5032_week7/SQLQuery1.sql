﻿-- Creating table 'Students'
create table [dbo].[Students](
	[Id] int identity(1,1) not null,
	[FirstName] nvarchar(max) not null,
	[LastName] nvarchar(max) not null,
	[UserId] nvarchar(max) not null 
	primary key (Id)
);
GO

-- Creating table 'Units'
create table [dbo].[Units](
	[Id] int identity(1,1) not null,
	[Name] nvarchar(max) not null,
	[Description] nvarchar(max) not null,
	[StudentId] int not null
	primary key (Id),
	foreign key (StudentId) references Students(Id)
);
GO